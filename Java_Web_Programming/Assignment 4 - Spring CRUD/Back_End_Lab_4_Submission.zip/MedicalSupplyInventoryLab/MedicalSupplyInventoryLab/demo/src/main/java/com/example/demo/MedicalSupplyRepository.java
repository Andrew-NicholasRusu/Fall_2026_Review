package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicalSupplyRepository extends JpaRepository<MedicalSupply, Long> {
}
