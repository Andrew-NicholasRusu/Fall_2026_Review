package com.example.demo;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller // This annotation indicates that this class is a controller
public class MedicalSupplyController {

    private final MedicalSupplyService service;

    public MedicalSupplyController(MedicalSupplyService service) {
        this.service = service;
    }

    @GetMapping("/") // localhost:8080/
    public String home() {
        return "redirect:/supplies";
    }

    // READ to list all supplies
    @GetMapping("/supplies") // localhost:8080/supplies
    public String listSupplies(Model model) {
        model.addAttribute("supplies", service.getAllSupplies());
        return "supplies";
    }

    // CREATE
    @GetMapping("/supplies/new") // localhost:8080/supplies/new
    public String showAddForm(Model model) {
        model.addAttribute("supply", new MedicalSupply());
        return "supply-form";
    }

    // UPDATE
    @GetMapping("/supplies/edit/{id}") // localhost:8080/supplies/edit/1
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("supply", service.getSupplyById(id));
        return "supply-form";
    }
    @PostMapping("/supplies/save") // localhost:8080/supplies/save
    public String saveSupply(@Valid @ModelAttribute("supply") MedicalSupply supply,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "supply-form";
        }

        boolean isNew = supply.getId() == null;
        service.saveSupply(supply);
        redirectAttributes.addFlashAttribute("message",
                isNew ? "Medical supply added successfully." : "Medical supply updated successfully.");
        return "redirect:/supplies";
    }

    // DELETE confirmation
    @GetMapping("/supplies/delete/{id}") // localhost:8080/supplies/delete/1
    public String showDeleteConfirmation(@PathVariable Long id, Model model) {
        model.addAttribute("supply", service.getSupplyById(id));
        return "supply-delete";
    }

    // DELETE by ID
    @PostMapping("/supplies/delete/{id}") // localhost:8080/supplies/delete/1
    public String deleteSupply(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        service.deleteSupplyById(id);
        redirectAttributes.addFlashAttribute("message", "Medical supply deleted successfully.");
        return "redirect:/supplies";
    }
}
