package com.example.demo;

import com.example.demo.SupplyNotFoundException;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;


@ControllerAdvice // This annotation indicates that this class is a controller advice
public class GlobalExceptionHandler {

    @ExceptionHandler(SupplyNotFoundException.class) // This exception handler handles supply not found errors
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleNotFound(SupplyNotFoundException ex, Model model) {
        model.addAttribute("message", ex.getMessage());
        return "supply-error";
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class) // This exception handler handles invalid ID errors
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleInvalidId(MethodArgumentTypeMismatchException ex, Model model) {
        model.addAttribute("message", "The requested medical supply ID is not valid.");
        return "supply-error";
    }

    @ExceptionHandler(DataAccessException.class) // This exception handler handles database-related errors
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleDatabaseError(DataAccessException ex, Model model) {
        model.addAttribute("message", "A database error occurred. Please try again.");
        return "supply-error";
    }
}

