package com.example.demo;

public class SupplyNotFoundException extends RuntimeException {

    public SupplyNotFoundException(Long id) {
        super("Medical supply with ID " + id + " was not found.");
    }
}
