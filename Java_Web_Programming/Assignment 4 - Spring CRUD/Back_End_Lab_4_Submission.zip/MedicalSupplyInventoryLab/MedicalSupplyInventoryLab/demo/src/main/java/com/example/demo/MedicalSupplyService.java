package com.example.demo;

import org.springframework.stereotype.Service;
import java.util.List;

@Service // This annotation indicates that this class is a service
public class MedicalSupplyService {

    private final MedicalSupplyRepository repository;

    public MedicalSupplyService(MedicalSupplyRepository repository) {
        this.repository = repository;
    }

    public List<MedicalSupply> getAllSupplies() {
        return repository.findAll();
    }

    public MedicalSupply getSupplyById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new SupplyNotFoundException(id));
    }

    public MedicalSupply saveSupply(MedicalSupply supply) {

        if (supply.getId() != null && !repository.existsById(supply.getId())) {
            throw new SupplyNotFoundException(supply.getId());
        }

        supply.setName(trim(supply.getName()));
        supply.setCategory(trim(supply.getCategory()));
        supply.setVendor(trim(supply.getVendor()));
        supply.setDescription(trim(supply.getDescription()));

        return repository.save(supply);
    }

    public void deleteSupplyById(Long id) {
        if (!repository.existsById(id)) {
            throw new SupplyNotFoundException(id);
        }
        repository.deleteById(id);
    }

    private String trim(String value) {
        return value == null ? null : value.trim();
    }
}
