﻿using System;


namespace SmartParcelDeliveryManagementSystem
{
    public class ExpressDelivery : Delivery
    {
        public int PriorityLevel { get; private set; }
        public double PriorityFee { get; private set; }

        public ExpressDelivery(
            int trackingNumber,
            string recipientName,
            string destination,
            double weight,
            int priorityLevel)
            : base(trackingNumber, recipientName, destination, weight)
        {
            PriorityLevel = priorityLevel;

            // Higher priority means a larger additional fee
            PriorityFee = priorityLevel * 4.00;
        }

        public override double CalculateDeliveryCost()
        {
            const double baseCharge = 10.00;
            const double costPerKilogram = 2.50;

            return baseCharge + (Weight * costPerKilogram) + PriorityFee;
        }

        public void ShowExpressInformation()
        {
            Console.WriteLine($"Express priority level: {PriorityLevel}");
            Console.WriteLine($"Express priority fee: {PriorityFee}");
        }

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            ShowExpressInformation();
        }
        public override void DeliveryStatusDisplay() => DisplayDetails();
    }
}