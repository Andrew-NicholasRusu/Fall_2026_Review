﻿using System;

namespace SmartParcelDeliveryManagementSystem
{
    public interface IDeliveryCapacity
    {
        double MaximumWeight 
        { 
            get; 
        }

        bool CanAcceptPackage(double packageWeight);

        void DeliveryCapacityDetails();
    }
}
