﻿using System;


namespace SmartParcelDeliveryManagementSystem
{
    public abstract class Delivery
    {
        // Static property: shared by every Delivery object
        public static int TotalDeliveries 
        { 
            get; private set; 
        }

        // Instance properties: each delivery object has its own values.
        public int TrackingNumber
        {
            get; private set;
        }
        public string RecipientName
        {
            get; private set;
        }
        public string Destination
        {
            get; private set;
        }
        public string DeliveryStatus
        {
            get; private set;
        }
        private double _weight;
        public double Weight
        {
            get => _weight;
            
            set
            {
                if (value < 0)
                { 
                    Console.WriteLine("Package weight should not be an invalid negative value.");
                    _weight = 0; // makes a value equal to 0
                }
                else
                {
                    _weight = value; // make thee value equal to what was given
                }
            }
        }

        public Delivery(int trackingNumber, string recipientName, string destination, double weight)
        {
            TrackingNumber = trackingNumber;
            RecipientName = recipientName;
            Destination = destination;
            Weight = weight;
            DeliveryStatus = "Processing"; //default status
            TotalDeliveries++;
        }

        public abstract double CalculateDeliveryCost();

        /** Part 2 */

        // regular paramater
        public void UpdateStatus(string newStatus)
        {
            DeliveryStatus = newStatus;
            Console.WriteLine($"Status for Tracking id: {TrackingNumber} updated to {DeliveryStatus}");
        }

        // ref paramater
        public void RerouteDelivery(ref string routeLog, string newDestination)
        {
            routeLog += $" -> {newDestination}";
            Destination = newDestination;
            

            Console.WriteLine(
                $"Package rerouted to {Destination}. Route log updated.");
        }

        // out paramater
        public bool TryGetWeightCategory(out string category)
        {

            if (Weight <= 2.0)
            {
                category = "Light";
                return true;
            }
            else if (Weight <= 10.0)
            {
                category = "Medium";
                return true;
            }
            else
            {
                category = "Heavy";
                return true;
            }
            
        }

        // in paramater
        public void CheckTrackingCode(in int expectedCode)
        {
            if (TrackingNumber == expectedCode)
            {
                Console.WriteLine(
                    $"Tracking code check successful for {TrackingNumber}.");
            }
            else
            {
                Console.WriteLine(
                    $"Tracking code check failed. Expected {expectedCode}, " +
                    $"but this delivery has tracking number {TrackingNumber}.");
            }
        }

        // optional paramater
        public void AddDeliveryNote(string note, bool isUrgent = false)
        {
            string urgency = isUrgent ? $"URGENT: {note}" : note;

            Console.WriteLine($"Delivery note added: {urgency} {note}");
        }

        // variable number of arguments (params parameter)
        public void SetPackageContents(params string[] contents)
        {
            Console.WriteLine($"Delivery #{TrackingNumber} contains {contents.Length} items");
            foreach(var item in contents)
            {
                Console.WriteLine($"- {item}");
            }
            
        }

        public virtual void DisplayDetails()
        {
            Console.WriteLine();
            Console.WriteLine("----- Delivery Details -----");
            Console.WriteLine($"Tracking ID: {TrackingNumber}");
            Console.WriteLine($"Recipient: {RecipientName}");
            Console.WriteLine($"Destination: {Destination}");
            Console.WriteLine($"Weight: {Weight} kg");
            Console.WriteLine($"Status: {DeliveryStatus}");
            Console.WriteLine($"Delivery cost: {CalculateDeliveryCost()}");
            Console.WriteLine("----------------------------");
        }
        public virtual void DeliveryStatusDisplay() => DisplayDetails();
    }
}
