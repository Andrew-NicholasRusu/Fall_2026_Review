﻿using System;

namespace SmartParcelDeliveryManagementSystem
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("SMART PARCEL DELIVERY MANAGEMENT SYSTEM");
            Console.WriteLine();

            // -------------------------------------------------
            // Part 4 and Part 5:
            // Create different derived delivery objects
            // -------------------------------------------------

            StandardDelivery standardDelivery = new StandardDelivery(
                    trackingNumber: 1001,
                    recipientName: "Maria Johnson",
                    destination: "Boston",
                    weight: 5.5
                );

            StandardDelivery standardDelivery2 = new StandardDelivery(
                    trackingNumber: 1002,
                    recipientName: "Carlos Gomez",
                    destination: "Chicago",
                    weight: 14.0
                );

            ExpressDelivery expressDelivery = new ExpressDelivery(
                    trackingNumber: 2001,
                    recipientName: "David Smith",
                    destination: "New York",
                    weight: 2.0,
                    priorityLevel: 3
                );

            // Demonstrate that each object has its own instance state
            Console.WriteLine("Initial delivery information:");

            standardDelivery.DisplayDetails();
            standardDelivery2.DisplayDetails();
            expressDelivery.DisplayDetails();

            // -------------------------------------------------
            // Part 3:
            // Demonstrate the shared static member
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine( $"Total deliveries created: {Delivery.TotalDeliveries}");

            // -------------------------------------------------
            // Part 8:
            // Valid and invalid property 
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing valid and invalid weight assignments:");
            Console.WriteLine($"Current Standard Delivery weight: {standardDelivery.Weight} kg");
            standardDelivery.Weight = 7.5;
            Console.WriteLine(
                $"Valid weight assignment: {standardDelivery.Weight} kg"
            );


            Console.WriteLine($"Assigning -4.0 weight");
            standardDelivery.Weight = -4.0;
            Console.WriteLine(
                $"Weight after invalid assignment: {standardDelivery.Weight} kg"
            );

            // -------------------------------------------------
            // Part 2:
            // Regular parameter passed by value
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing regular parameter:");

            standardDelivery.UpdateStatus("Out for delivery");

            // -------------------------------------------------
            // Part 2:
            // ref parameter
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing ref parameter:");

            string routeLog = "Boston Distribution Center";

            Console.WriteLine($"Route Log BEFORE reroute: {routeLog}");

            standardDelivery.RerouteDelivery(
                ref routeLog,
                "Cambridge Pickup Point"
            );

            Console.WriteLine($"Route Log AFTER reroute: {routeLog}");

            // -------------------------------------------------
            // Part 2:
            // out parameter
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing out parameter:");

            bool categoryFound =
                standardDelivery.TryGetWeightCategory(out string category);

            Console.WriteLine($"Category found: {categoryFound}");
            Console.WriteLine($"Weight category: {category}");

            // -------------------------------------------------
            // Part 2:
            // in parameter
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing in parameter:");

            int expectedTrackingCode = 1001;

            standardDelivery.CheckTrackingCode(
                in expectedTrackingCode
            );

            // -------------------------------------------------
            // Part 2:
            // Optional parameter and named arguments
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine(
                "Testing optional parameter and named arguments:"
            );

            // Uses the default value false for isUrgent
            standardDelivery.AddDeliveryNote(
                "Leave package at the front desk"
            );

            // Uses named arguments
            expressDelivery.AddDeliveryNote(
                note: "Customer requested signature upon delivery",
                isUrgent: true
            );

            // -------------------------------------------------
            // Part 2:
            // params parameter variable number of arguments
            // -------------------------------------------------

            Console.WriteLine("\n Params parameter (SetPackageContents");
            standardDelivery.SetPackageContents("Books", "Notebook", "Pens");
            expressDelivery.SetPackageContents("Mobile Phone", "Charger");

            // Interface Implementation (IDelivery Capacity)

            Console.WriteLine();
            Console.WriteLine("Testing params parameter:");

            // -------------------------------------------------
            // Part 6:
            // Interface implementation
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing interface implementation:");


            standardDelivery.DeliveryCapacityDetails();

            Console.WriteLine(
                $"Can accept 15 kg? " +
                $"{standardDelivery.CanAcceptPackage(15.0)}"
            );

            Console.WriteLine(
                $"Can accept 25 kg? " +
                $"{standardDelivery.CanAcceptPackage(25.0)}"
            );

            // The object can also be stored in an interface variable.
            IDeliveryCapacity capacityChecker = standardDelivery;
            Console.WriteLine("Accessing capacity info via IdeliveryCapacity intereface");
            capacityChecker.DeliveryCapacityDetails();

            Console.WriteLine(
                $"Maximum weight through interface reference: " +
                $"{capacityChecker.MaximumWeight} kg"
            );

            // -------------------------------------------------
            // Express-specific behavior
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing express-specific behavior:");

            expressDelivery.ShowExpressInformation();

            // -------------------------------------------------
            // Part 5:
            // Abstract Class and Polymorphism
            // -------------------------------------------------
            Console.WriteLine();
            Console.WriteLine("Abstract Class and polymophic overriding");

            Delivery deliveryRefStandard = standardDelivery;
            Delivery deliveryRefExpress = expressDelivery;

            Console.WriteLine($"Polymorphic cost - Standard Deliver: {deliveryRefStandard.CalculateDeliveryCost():C}");
            Console.WriteLine($"Polymorphic cost - Standard Deliver: {deliveryRefExpress.CalculateDeliveryCost():C}");
            // -------------------------------------------------
            // Part 7:
            // Reference-type behavior
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine("Testing reference-type behavior:");

            StandardDelivery firstReference = standardDelivery;
            StandardDelivery secondReference = firstReference;

            Console.WriteLine($"Status before change via second reference: '{firstReference.DeliveryStatus}'");
            secondReference.UpdateStatus("Delivered");

            Console.WriteLine(
                $"Status through first reference: " +
                $"{firstReference.DeliveryStatus}"
            );

            Console.WriteLine(
                $"Status through second reference: " +
                $"{secondReference.DeliveryStatus}"
            );

            Console.WriteLine(
                "Both variables refer to the same StandardDelivery object."
            );

            // -------------------------------------------------
            // Part 8:
            // Final Overview and verification
            // -------------------------------------------------

            Console.WriteLine();
            Console.WriteLine(
                "FInal delivery object states:"
            );

            standardDelivery.DisplayDetails();
            standardDelivery2.DisplayDetails();
            expressDelivery.DisplayDetails();
                     

            Console.WriteLine();
            Console.WriteLine("Final delivery information:");


            Console.WriteLine();
            Console.WriteLine(
                $"Final total deliveries: {Delivery.TotalDeliveries}"
            );
        }
    }
}