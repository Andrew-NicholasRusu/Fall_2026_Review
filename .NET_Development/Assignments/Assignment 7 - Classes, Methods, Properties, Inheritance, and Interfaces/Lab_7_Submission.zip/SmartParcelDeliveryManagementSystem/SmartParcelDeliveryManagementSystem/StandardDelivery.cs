﻿using System;

namespace SmartParcelDeliveryManagementSystem
{
    public class StandardDelivery : Delivery, IDeliveryCapacity
    {
        public double MaximumWeight { get; } = 20.0;

        public StandardDelivery(
            int trackingNumber,
            string recipientName,
            string destination,
            double weight)
            : base(trackingNumber, recipientName, destination, weight)
        {
        }

        public override double CalculateDeliveryCost()
        {
            const double baseCharge = 5.00;
            const double costPerKilogram = 1.50;

            return baseCharge + (Weight * costPerKilogram);
        }

        public bool CanAcceptPackage(double packageWeight)
        {
            return packageWeight >= 0 && packageWeight <= MaximumWeight;
        }

        public void DeliveryCapacityDetails()
        {
            Console.WriteLine($"Service Type: Standard Deliver (Max Capacity: {MaximumWeight} kg)");
        }
        public override void DeliveryStatusDisplay() => DisplayDetails();
    }
}